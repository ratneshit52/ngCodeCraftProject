# Webpack config

This directory contains all configuration for webpack.
If you want to try our webpack's configuration, just go to root folder and type:

```javascript
npm install && npm run webpack:start
```

Eventually theses files are the main config you may need:
* [vendor.ts](vendor.ts)
* [demo/src/tsconfig.webpack.json](../demo/src/tsconfig.webpack.json)