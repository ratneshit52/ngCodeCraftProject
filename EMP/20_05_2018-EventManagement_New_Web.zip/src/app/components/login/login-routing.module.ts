import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../services/auth-guard.service';
import { AuthenticationService } from '../services/authentication.service'
import { LoginPageComponent } from './login-page.component';


const routes: Routes = [
    {
        path: 'login',
        component: LoginPageComponent
    }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
    providers: [
        AuthGuard,
        AuthenticationService
    ]
})
export class LoginRoutingModule { }
