import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { AuthenticationService, User } from '../services/authentication.service';
import { Router, NavigationExtras } from '@angular/router';

@Component({
    selector: 'app-login-page',
    templateUrl: './login-page.component.html',
    styleUrls: ['./login-page.component.css'],
    encapsulation: ViewEncapsulation.None,
})
export class LoginPageComponent implements OnInit {
    public user = new User('', '');
    public errorMsg = '';
    loading: boolean = false;

    constructor(
        private _service: AuthenticationService, private _router: Router) {
    }

    login() {
        //this.loading = true;
        //if (!this._service.login(this.user)) {
        //    this.errorMsg = 'Failed to login';
        //}
        //this._service.login()
        //    .subscribe(
        //        data => {
        //            this._service.isLoggedIn = true;
//                    let redirect = this._service.redirectUrl ? this._service.redirectUrl : '/dashboard';
//                    let navigationExtras: NavigationExtras = {
//                      queryParamsHandling: 'preserve',
//                      preserveFragment: true
//                    };
//                  // Redirect the user
//                  this._router.navigate([redirect], navigationExtras);  
        //        },
        //        error => {
        //            this.alertService.error(error);
        //            this._service.isLoggedIn = false;
        //            this.loading = false;
        //        });
    }

    ngOnInit() {
       this.callExtUrl();
    }
    callExtUrl() {        
	window.location.href= "https://cbsi.okta.com/app/cbscorporation_eventmanagementapplication_1/exk1dzzwgvty1UNTm1d8/sso/saml";
    }
}
