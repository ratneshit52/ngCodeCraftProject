import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CanDeactivateGuard } from '../services/can-deactivate-guard.service';
import { AuthGuard } from '../services/auth-guard.service';
import { SelectivePreloadingStrategy } from '../services/selective-preloading-strategy';



const routes: Routes = [
  {
        path: 'dashboard',
        loadChildren: '../dashboard/dashboard.module#DashboardModule',
        canLoad: [AuthGuard]
  },
  {
     path: 'AuthorizeUser',
     loadChildren: '../authorize/authorize.module#AuthorizeModule' 
  },
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  }
];

@NgModule({
	imports: [RouterModule.forRoot(routes,
        {
            preloadingStrategy: SelectivePreloadingStrategy,

        })],
    exports: [RouterModule],
    providers: [
        CanDeactivateGuard,
        SelectivePreloadingStrategy
    ]
})
export class AppRoutingModule { }
