import { Injectable, Output, EventEmitter } from '@angular/core';
import { Headers, Http, Response, RequestOptions } from '@angular/http';

import 'rxjs/add/operator/toPromise';

@Injectable()
export class DataSourceService {
    private headers = new Headers({ 'Content-Type': 'application/json'});
    private options = new RequestOptions({headers: this.headers});
    //public url: string;  // URL to web api
  private data: any;
  public refresh: boolean = false;

  @Output() change: EventEmitter<boolean> = new EventEmitter()

    constructor(private http: Http) {
     }

  public setDetails(eventData: any) {
    debugger;
        this.data = eventData;
    }

    public getDetails() {
        return this.data;
    }

    getAllData(url) {
        return this.http.get(url).map(res => res.json());
    }

    getOrderRequests(url: string): Promise<any> {
        return this.http.get(url)
            .toPromise()
            .then(response => response.json().data)
            .catch(this.handleError);
    }

  create(orderRequest: any, url: string): Promise<any> {
    debugger;
        return this.http
            .post(url, JSON.stringify(orderRequest), this.options)
            .toPromise()
          .then((res: any) => {
            debugger;
            if (res._body === "1") {
              res.json().data;
              this.change.emit(true);
            } else if (res._body === "0") {
              this.change.emit(false);
            }
          })
            .catch(this.handleError);
    }

    update(orderRequest: any, url: string): Promise<any> {
        return this.http
            .put(url, JSON.stringify(orderRequest), this.options)
            .toPromise()
          .then(() => {
            orderRequest;
            debugger;
            this.refresh = !this.refresh;
            this.change.emit(this.refresh);
          })
            .catch(this.handleError);
    }

  delete(orderRequest: any, url: string): Promise<void> {
    debugger;
        return this.http.delete(url, this.options)
            .toPromise()
          .then((res: any) => {
            debugger;
            if (res._body === "1") {
              res.json().data;
              this.change.emit(true);
            } else if (res._body === "0") {
              this.change.emit(false);
            }
          })
            .catch(this.handleError);
    }
  getDataRecord(url: string): Promise<any> {
        let headers = new Headers({'Content-Type': 'text/xml'}); 
        //Origin, X-Requested-With, Content-Type, Accept");
        headers.append('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
        headers.append('Access-Control-Allow-Methods', 'GET');
        headers.append('Access-Control-Allow-Origin', 'https://cbseventmanagement-frontend-dot-thermal-wonder-200107.appspot.com/AuthorizeUser');
        //({ 'Content-Type': 'text/xml'});
        //,{ 'Access-Control-Allow-Origin': '*' }
        let options = new RequestOptions({ headers: headers });
        // let headers = new Headers({ 'Access-Control-Allow-Origin': '*' });
        debugger;
        return this.http.get(url, options)
        .toPromise()
        .then(response => response.text())
        .catch(this.handleError);
        }


    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }
}
