import { Injectable, Inject } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { Router, NavigationExtras } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'

export class User {
    userName: string;
    password: string;
    constructor(userName: string, password: string) {
        this.userName = userName;
        this.password = password;
    }
}

var users = [
  new User('admin','')
];

@Injectable()
export class AuthenticationService {
    public isLoggedIn = true;
    public redirectUrl: string = "";

  constructor(
      private _router: Router, private http: Http) { }

    //oktaLogin() {
    //    this.window.location.href("")
    //}
  logout() {
      localStorage.removeItem("user");
      this.isLoggedIn = false;
      this._router.navigate(['/login']);
  }

    login(user: any) {

        //return this.http.post<any>('/api/authenticate', { user.name: username, user.password: password })
        //    .map(user => {
        //        // login successful if there's a condition write here
        //        if (user && user.token) {
        //            // store user details and jwt token in local storage to keep user logged in between page refreshes
        //            localStorage.setItem('user', JSON.stringify(user));
        //        }
        //        return user;
        //    });
        console.log(user + "user")
        var authenticatedUser = users.find(u => u.userName === user.name);
        console.log(authenticatedUser)
          if (authenticatedUser) {
            this.isLoggedIn = true;
            localStorage.setItem("user", JSON.stringify(authenticatedUser));
            let redirect = this.redirectUrl ? this.redirectUrl : '/dashboard';
            let navigationExtras: NavigationExtras = {
                queryParamsHandling: 'preserve',
                preserveFragment: true
            };
            // Redirect the user
            this._router.navigate([redirect], navigationExtras);
          return true;
        }
    return false;
  }

   checkCredentials( ){
    if (localStorage.getItem("user") === null){
        this._router.navigate(['/login']);
    }
  } 
}
