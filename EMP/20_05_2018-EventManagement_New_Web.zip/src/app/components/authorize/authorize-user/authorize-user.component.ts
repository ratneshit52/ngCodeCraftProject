import { Component, OnInit, ViewChild } from '@angular/core';
import { Http, ResponseType } from '@angular/http';
import { Router, NavigationExtras } from '@angular/router';
import { reduce } from 'rxjs/operator/reduce';
import { DataSourceService } from '../../services/dashboard-data.service';
import { NavigationComponent } from '../../dashboard/navigation/navigation.component'

@Component({
  selector: 'app-authorize-user',
  templateUrl: './authorize-user.component.html',
  styleUrls: ['./authorize-user.component.css'],
  providers: [DataSourceService]
})
export class AuthorizeUserComponent implements OnInit {
  landingPage:any;
  
  public Authurl: string = "https://cbseventmanagement-frontend-dot-thermal-wonder-200107.appspot.com/AuthorizeUser";
  public url : string = "https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/AuthorizeUser/";
 // public url : string = "http://localhost:58905/api/AuthorizeUser/";
  //public url : string = "http://localhost:58905/api/AuthorizeUser/";
   public  userid : string ="vvanama";
  //public  userid : string ="mmurt0410";
   //public  userid : string ="fhfj";
    //public  userid : string ="venkat";
  
   public dData: any[] = [];

  

  @ViewChild(NavigationComponent) navDataPass;

  constructor(public http: Http, private router: Router,private _dataSource: DataSourceService) {
    //this.AuthorizeUserResponse();
  }
  ngOnInit() {
    //  this.router.navigate(['dashboard'])
   // debugger;
    //this._dataSource.currentMessage.subscribe(message => this.message = message)
    
   // this.AuthorizeUserResponse()
    this.AuthorizeUser(this.userid);
   // this._dataSource.currentMessage.subscribe(message => this.message = message)
   // this.newMessage();
    //  this.userservice.getUserDetails();
    //this.source.reset();
    //console.info(this.source);
  }
    newMessage() {
     // debugger;
    //this._dataSource.changeMessage(this.message)
  }

  AuthorizeUserResponse() {
    this._dataSource.getDataRecord(this.Authurl)
    .then((d) => {
     // debugger;
      console.log(d)
      //let data = xml2js.parseString(d.text());
      // var jsonText = JSON.stringify(xml));
      
      //return this.dData = data
      return this.dData = d

    })
}


  //getAuthorizePage(event: any) {
  //    //debugger;
  //    this._dataSource.getDataRecord(event, this.getURL);
  //}
   
  //AuthorizeUser() {
  //  var res = [];
  //  return this.http.get(this.url).subscribe(

  //    (res: any) => {
  //      debugger;
  //      console.log(res.json())
  //      var pagename = res.json()[0].landingPage;
  //      this.router.navigate(['/dashboard/' + pagename]);
  //    //  this.router.navigate(['/dashboard']);

  //  })

  AuthorizeUser(userid:string) {
    //debugger;
    //var res = [];
    return this.http.get(this.url + userid).subscribe(
      (res: any) => {
        debugger;
        console.log(res.json())
        this.landingPage = res.json()[0].landingPage.toLowerCase();
        var pagename = res.json()[0].pageNames;  
        
        this.router.navigate(['dashboard/' + this.landingPage]);

        //this.message= pagename;
        sessionStorage.setItem("new value", JSON.stringify(pagename));

        //localStorage.setItem("new value", pagename)
        //this.navDataPass.navDetail = pagename;
      })
  }

  // AuthorizeUserResponse() {
  //   debugger;
  //   return this.http.get(this.url).subscribe(
  //     (res: any) => {
  //       console.log(res.json())
        
  //     //  var pagename = res.json()[0].landingPage;
  //     //  var pagename = res.json()[0].landingPage;
  //      // this.router.navigate(['dashboard/' + pagename]);
  //      //this.AuthorizeUser(userid);
  //     })
  // }

}

//private userservice: UserService
//window.location.href=

// public url: string = "https://cbseventmanagement-dot-thermal-wonder-200107.appspot.com/AuthorizeUser";
