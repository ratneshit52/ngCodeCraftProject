import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuthorizeRoutingModule } from './authorize-routing.module';
import { DataSourceService } from '../services/dashboard-data.service';
import { AuthorizeUserComponent } from './authorize-user/authorize-user.component';

@NgModule({
  imports: [
    CommonModule,
    AuthorizeRoutingModule
  ],
  declarations: [AuthorizeUserComponent],
  providers: [DataSourceService]
})
export class AuthorizeModule { }
