import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthorizeUserComponent } from './authorize-user/authorize-user.component';

const routes: Routes = [
  {
      path: '',
      component: AuthorizeUserComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthorizeRoutingModule { }
