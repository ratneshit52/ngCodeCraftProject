import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';
import { UserManagmentComponent } from './user-managment/user-managment.component';
import { UserRoleManagmentComponent } from './user-role-managment/user-role-managment.component';
import { EventsCriteriaComponent } from './events-criteria/events-criteria.component';
import { EventsMappingComponent } from './events-mapping/events-mapping.component';
import { PostionComponent } from './postion-page/postion.component';
import { ReportsComponent } from './reports-page/reports.component';

import { AuthGuard } from '../services/auth-guard.service';

const routes: Routes = [
    {
        path: '',
        component: DashboardPageComponent,
        children: [
            {
                path: '',
                children: [
                    { path: 'usermanagement', component: UserManagmentComponent },
                    { path: 'userrolemanagement', component: UserRoleManagmentComponent },
                    { path: 'eventcriteria', component: EventsCriteriaComponent },
                    { path: 'eventmapping', component: EventsMappingComponent },
                    { path: 'posting', component: PostionComponent },
                    { path: 'reports', component: ReportsComponent },
                    { path: '', redirectTo: '', pathMatch:'full' }
                ]
            }
        ]
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
