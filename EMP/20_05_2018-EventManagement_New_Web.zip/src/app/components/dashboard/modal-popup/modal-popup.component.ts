import { Component, OnInit, Output, EventEmitter } from '@angular/core';
declare const $;

@Component({
    selector: 'modal-popup',
    templateUrl: './modal-popup.component.html',
    styleUrls: ['./modal-popup.component.css']
})

export class MOdalPopupComponent implements OnInit {

    public templateData: any;

    @Output() notify: EventEmitter<string> = new EventEmitter<string>();

    constructor(){

    }

    ngOnInit(){
        
    }

    confBtn(){
        this.notify.emit();
        $('#confirmationPopup').modal('hide');
    }

}
