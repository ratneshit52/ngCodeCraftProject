import { Component, OnInit,OnDestroy } from '@angular/core';
//import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { AuthenticationService } from '../../services/authentication.service';
import { DataSourceService } from '../../services/dashboard-data.service';
import {AuthorizeUserComponent} from '../../authorize/authorize-user/authorize-user.component';
import { Subscription } from 'rxjs/Subscription';
import { disableDebugTools } from '@angular/platform-browser';
@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css'],
  providers: [DataSourceService]
})

export class NavigationComponent implements OnInit {
  message :any;
  public navVal: any = {
    usermanagement: null,
    eventcriteria: null,
    posting: null,
    reports: null
  };

    constructor(public _authServices: AuthenticationService,private _dataSource: DataSourceService) {}
           
    ngOnInit( ): void {
      debugger;
      this.message = JSON.parse(sessionStorage.getItem("new value"));
      if(this.message !== null) {
        if(this.message instanceof Array){
          this.message = this.message.map((k) => k.toLowerCase());
          Object.keys(this.navVal).forEach((v) => {
            if(this.message.indexOf(v) > -1) {
              this.navVal[v] = true;
            }
          })
        } else {
          let val = this.message.toLowerCase();
          debugger;
          Object.keys(this.navVal).forEach((v) => {
            if(v === val) {
              this.navVal[v] = true;
            }
          })
        }
      }
    }
  }





