import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { Ng2SmartTableModule } from 'ng2-smart-table';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardPageComponent } from './dashboard-page/dashboard-page.component';
import { NavigationComponent } from './navigation/navigation.component';
import { ReportsComponent } from './reports-page/reports.component';
import { PostionComponent } from './postion-page/postion.component';
import { UserManagmentComponent } from './user-managment/user-managment.component';
import { LandingComponent } from './landing-page/landing.component';
import { UserRoleManagmentComponent } from './user-role-managment/user-role-managment.component';
import { CreateUserComponent } from './user-managment/creat-page/create-user.component';
import { CreateRoleComponent } from './user-role-managment/creat-page/create-role.component';
import { FilterUserComponent } from './user-managment/filter-user/filter-user.component';
import { FilterRoleComponent } from './user-role-managment/filter-user/filter-role.component';
import { EditUserComponent } from './user-managment/edit-user/edit-user.component';
import { EditRoleComponent } from './user-role-managment/edit-user/edit-role.component';
import { EventsCriteriaComponent } from './events-criteria/events-criteria.component';
import { CreateEventComponent } from './events-criteria/create-events/create-events.component';
import { EditEventComponent } from './events-criteria/edit-events/edit-events.component';
import { FilterEventComponent } from './events-criteria/filter-events/filter-events.component';
import { EventsMappingComponent } from './events-mapping/events-mapping.component';
import { HeaderComponent } from './header/header.component';
import { DataSourceService } from '../services/dashboard-data.service';
import { MOdalPopupComponent } from '../dashboard/modal-popup/modal-popup.component'
import { ModalPopupAlertComponent } from '../dashboard/modal-popup-alert/modal-popup-alert.component';
import { MultiSelectModule } from 'primeng/multiselect';
import { AccordionModule } from 'primeng/accordion';
import { MenuItem } from 'primeng/api'; 

@NgModule({
  imports: [
    CommonModule,
    DashboardRoutingModule,
    Ng2SmartTableModule,
    FormsModule,
    ReactiveFormsModule,
    MultiSelectModule,
    AccordionModule
  ],
  declarations: [
    DashboardPageComponent,
    NavigationComponent,
    ReportsComponent,
    UserManagmentComponent,
    EventsCriteriaComponent,
    EventsMappingComponent,
    PostionComponent,
    HeaderComponent,
    CreateUserComponent,
    EditUserComponent,
    FilterUserComponent,
    UserRoleManagmentComponent,
    EditRoleComponent,
    FilterRoleComponent,
    CreateRoleComponent,
    LandingComponent,
    EventsMappingComponent,
    MOdalPopupComponent,
    CreateEventComponent,
    EditEventComponent,
    FilterEventComponent,
    ModalPopupAlertComponent
    ],
    providers: [
        DataSourceService
    ]
})
export class DashboardModule { }
