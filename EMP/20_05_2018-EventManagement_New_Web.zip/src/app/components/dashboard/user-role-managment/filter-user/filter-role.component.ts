import { Component, ViewChild, Input, OnInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { Http } from '@angular/http'


interface DropDown {
  name: string
}
@Component({
    selector: 'filter-role',
    templateUrl: 'filter-role.component.html',
  styleUrls: ['filter-role.component.css'],
  encapsulation: ViewEncapsulation.None
})

export class FilterRoleComponent implements OnInit {

    public userDetails: FormGroup;
  public data: any;
  public roleName: any;
  public pagePermission: any;
  public landing_Page: any;
  public pagePermissionValues: any[];
  public dropDownValues: any;
  public url: string = "https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/UserRole/PageDetails";
 // private url = 'http://localhost:58905/api/UserRole/PageDetails';
  pagePermissiondropdown: DropDown[] = [];
  pagePermissions: DropDown[];
  public source: LocalDataSource = new LocalDataSource();
    @Output() messageEvent = new EventEmitter<string>();

    public formName: any = {
        "title": "Search Criteria",
        "subBtnName": "SEARCH"
    }

  //public products: any = [
  //  { "name": "Event Criteria", "value": "EventCriteria" },
  //  { "name": "Posting", "value": "Posting" },
  //  { "name": "Reports", "value": "Reports" },
  //  { "name": "Role Management", "value": "RoleManagement" },
  //  { "name": "User Management", "value": "UserManagement" },

  //]

  constructor(
    private fb: FormBuilder, private http: Http
    ) {
    }

  ngOnInit(): void {
    this.dropListPagePermission()
      this.userDetails = this.fb.group({
          roleName: [''],
        pagePermission: ['']
      });
  }

  dropListPagePermission() {
    this.http.get(this.url)
      .subscribe(response => {
        this.dropDownValues = response.json();
        this.pagePermissionValues = this.dropDownValues["PageNames"];
        this.pagePermissionValues.forEach(e => {
          debugger;
          this.pagePermissiondropdown.push({
            name: e
          });
          this.pagePermissions = this.pagePermissiondropdown;
        })
      });
  }


    onSubmit(data: any) {
      debugger;
      const isEmpty = Object.keys(data.value).map((k) => data.value[k]).every(x => (x === null || x === '' || x === undefined ));
      if (isEmpty) {
            this.onRest()
            return true;
        }
        this.messageEvent.emit(data.value);
    }
    
  onRest() {
      this.messageEvent.emit(null);
    }

}
