﻿export class OrderRole {
    public rolename: string;
    public user_name: string;
    public pagepermission: any[];
    public landing_page: string;
    constructor(rolename: string, 
        user_name: string,
        pagepermission: any[],
        landing_page: string) {
        this.rolename = rolename;
        this.user_name = user_name;
        this.pagepermission = pagepermission;
        this.landing_page = landing_page;
    }
}
