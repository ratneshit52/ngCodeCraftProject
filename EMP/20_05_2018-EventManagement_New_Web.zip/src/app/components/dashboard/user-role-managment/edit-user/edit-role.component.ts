import { Component, ViewChild, Input, OnInit, Output, EventEmitter, ViewEncapsulation} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { OrderRole } from '../order-role';
import { DataSourceService } from '../../../services/dashboard-data.service';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { MenuItem } from 'primeng/api';
import { Http } from '@angular/http';
declare const $;

interface DropDown {
  name: string
}
@Component({
    selector: 'edit-role',
    templateUrl: '../creat-page/create-role.component.html',
  styleUrls: ['../creat-page/create-role.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class EditRoleComponent implements OnInit {

    orderRequests: OrderRole[] = [];
    public userDetails: FormGroup;
    public data: any;
    public editUrl: string;
    public roleName: any;
    public pagePermission: any;
    public landing_Page: any;
  public toggleED: any;
  public pagePermissionValues: any[];
  public landingPage: any[];
  public pagePermissionBindValues: any[];
  public url: string = "https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/UserRole/PageDetails";
  //private url = 'http://localhost:58905/api/UserRole/PageDetails';
  public dropDownValues: any;
  pagePermissiondropdown: DropDown[] = [];
  pagePermissions: DropDown[];
    public source: LocalDataSource = new LocalDataSource();
    @Input() orderRequest: OrderRole;
    @Output() editUserMang = new EventEmitter<string>();

    public formName: any = {
        "title": "UPDATE ROLE DETAILS",
        "subBtnName": "UPDATE",
        disabledVal: "disabled",
      compliteMsg: "Update Role Successfull."
    }


    constructor(
      private fb: FormBuilder,
      private appService: DataSourceService, private http: Http
    ) {
    }

  ngOnInit(): void {
    this.http.get(this.url)
      .subscribe(response => {
        this.dropDownValues = response.json();
        this.landingPage = this.dropDownValues["PageNames"];
        this.pagePermissionValues = this.dropDownValues["PageNames"];
        this.pagePermissiondropdown = [];
        this.pagePermissionValues.forEach(e => {
          debugger;
          this.pagePermissiondropdown.push({
            name: e
          });
        })     
        this.pagePermissions = this.pagePermissiondropdown;
      });
        this.userDetails = this.fb.group({
            roleName: ['', Validators.required],
            user_Name: [''],
            pagePermission: ['', Validators.required],
            landing_Page: ['', Validators.required]
        });
    }

  open() {
    debugger;
      this.data = this.appService.getDetails();
    this.pagePermissionValues = this.data.pagePermissionsList;
    this.pagePermissiondropdown = [];
    this.pagePermissionValues.forEach(e => {
      this.pagePermissiondropdown.push({
        name: e
      });
    })
        this.userDetails = this.fb.group({
            roleName: [this.data.roleName],
            user_Name: [this.data.user_Name],
            pagePermission: [this.pagePermissiondropdown],
            landing_Page: [this.data.landing_Page]
        })
    }

    openSource(source: any) {
        this.source = source;
        this.open();
    }

    emitToggleData(value: any) {
        this.editUserMang.emit(value)
    }

    onSubmit({ value, valid }: { value: OrderRole, valid: boolean }) {
        this.edit({ value, valid });
    }

    alertCall(){
        this.toggleED.formName = this.formName;
        $("#alertPopup").modal("show");
        this.close()
    }

    close() {
        if (!this.toggleED.editbox) {
            this.toggleED.editbox = !this.toggleED.editbox;
            this.toggleED.fullbox = !this.toggleED.fullbox;
        }
        this.emitToggleData(this.toggleED);
    }

    edit({ value, valid }: { value: OrderRole, valid: boolean }): void {
        let result = JSON.stringify(value);
        if (!result) {
            return;
        }
        this.appService.update(value, this.editUrl)
            .then(() => {
                this.source.update(this.data, value);
                this.source.refresh();
                this.alertCall()
                return null;
            });
        //this.source.update(this.data, value); no luck here as well
    }
}
