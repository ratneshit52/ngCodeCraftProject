export const setting = {
  "mode": "external",
    "actions": {
        "add": true,
        "position": "right"
    },
    "edit": {
        "inputClass": "form-control input-sm",
        "editButtonContent": "<img src='../../../../assets/images/edit.png'>",
        "saveButtonContent": "<i class='glyphicon glyphicon-ok' aria-hidden='true'></i>",
        "cancelButtonContent": "<i class='glyphicon glyphicon-remove' aria-hidden='true'></i>",
        "confirmSave": true
    },
    "delete": {
        "deleteButtonContent": "<img src='../../../../assets/images/delete.png'>",
        "confirmDelete": true
    },
    "add": {
        "inputClass": "form-control input-sm",
        "addButtonContent": "<label class='label label-info'>Create User</label>",
        "createButtonContent": "<i class='glyphicon glyphicon-pencil' aria-hidden='true'></i>",
        "cancelButtonContent": "<i class='glyphicon glyphicon-remove' aria-hidden='true'></i>",
        "confirmCreate": true
    },
    "columns": {
        "roleName": {
            "title": "Role Name",
        },
        "pagePermissionsList": {
            "title": "Page Permission"
        },
        "landing_Page": {
            "title": "Landing Page",
        }
    },
    "orderby": {
        "title": "Name",
        "filter": true
    },
    "purchased": {
        "title": "Purchased",
        "type": "html"
    },
    "filter": false,
    "attr": {
      "class": "table table-font-normal startFilterExternal preloaderTable"
      
    }
}
