import { Component, ViewChild, Input, OnInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { OrderRole } from '../order-role';
import { DataSourceService } from '../../../services/dashboard-data.service';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { MenuItem } from 'primeng/api';
import { Http } from '@angular/http';
declare const $;

interface DropDown {
  name: string
}
@Component({
    selector: 'create-role',
    templateUrl: 'create-role.component.html',
  styleUrls: ['create-role.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CreateRoleComponent implements OnInit {

    orderRequests: OrderRole[] = [];
    public userDetails: FormGroup;
    public toggleCU: any;
    public roleName: any;
    public pagePermission: any;
    public landing_Page: any;
  public postUrl: string;
  public pagePermissionValues: any[];
  public landingPage: any[];
  public dropDownValues: any;
  //= ['EventCriteria', 'Posting', 'Reports', 'RoleManagement','UserManagement'];
  public orderTypevalues: any[];
  public url: string = "https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/UserRole/PageDetails";
  //private url = 'http://localhost:58905/api/UserRole/PageDetails';
  pagePermissiondropdown: DropDown[] = [];
  pagePermissions: DropDown[];
    public source: LocalDataSource = new LocalDataSource();
    @Input() orderRole: OrderRole;
    @Output() toggleScreenCU = new EventEmitter<string>();

    public formName: any = {
        "title": "CREATE ROLE",
        "subBtnName": "SAVE",
        disabledVal: null,
       "compliteMsg": ""
    }

    constructor(
      private fb: FormBuilder,
      private appService: DataSourceService, private http: Http
    ) {
     }

  ngOnInit(): void {+
    this.appService.change.subscribe((data) => {
      debugger;
      if (!data) {
        this.formName.compliteMsg = "Role Already Exist...!";
      } else {
        this.formName.compliteMsg = "Create Role Successfull.";
      }

    })

    this.http.get(this.url)
      .subscribe(response => {
        this.dropDownValues = response.json();
        this.landingPage = this.dropDownValues["PageNames"];
        this.pagePermissionValues = this.dropDownValues["PageNames"];
        this.pagePermissionValues.forEach(e => {
          debugger;
          this.pagePermissiondropdown.push({
            name: e
          });
          this.pagePermissions = this.pagePermissiondropdown;
        })
      });
        this.userDetails = this.fb.group({
            roleName: ['', Validators.required],
            user_Name: [''],
            pagePermission: ['', Validators.required],
            landing_Page: ['', Validators.required]
        });
    }

  //public products: any = [
  //  { "name": "EventCriteria", "value": "eventcriteria" },
  //  { "name": "Posting", "value": "posting" },
  //  { "name": "Reports", "value": "reports" },
  //  { "name": "RoleManagement", "value": "rolemanagement" },
  //  { "name": "UserManagement", "value": "usermanagement" },
      
  // ]

    openSource(source: any) {
      this.source = source;
    }

    emitToggleData(value: any) {
        this.toggleScreenCU.emit(value)
    }

    onSubmit({ value, valid }: { value: OrderRole, valid: boolean }) {
        this.add({ value, valid });
        //this.close();
    }

    close() {
        if (!this.toggleCU.createbox) {
            this.toggleCU.createbox = !this.toggleCU.createbox;
            this.toggleCU.fullbox = !this.toggleCU.fullbox;
        }
        this.emitToggleData(this.toggleCU);
        this.userDetails.reset()
  }

  alertCall() {
    this.appService.change.subscribe((data) => {
      debugger;
      if (!data) {
        this.formName.compliteMsg = "User Already Exist...!";
      }
    })
    this.toggleCU.formName = this.formName;
    $("#alertPopup").modal("show");
    this.close()
  }

    add({ value, valid }: { value: OrderRole, valid: boolean }): void {
        let result = JSON.stringify(value);
        if (!result) {
            this.userDetails.reset()
            return;
        }
        this.appService.create(value, this.postUrl)
            .then(orderRequest => {
                this.orderRequests.push(orderRequest);
                this.source.add(orderRequest);
                this.source.refresh();
                this.userDetails.reset()
                this.alertCall()
            });
    }
}
