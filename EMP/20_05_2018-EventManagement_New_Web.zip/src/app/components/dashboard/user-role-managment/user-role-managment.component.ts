import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Http } from '@angular/http';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { MOdalPopupComponent } from '../modal-popup/modal-popup.component'
import { CreateRoleComponent } from './creat-page/create-role.component'
import { FilterRoleComponent } from './filter-user/filter-role.component'
import { EditRoleComponent } from './edit-user/edit-role.component'
import { DataSourceService } from '../../services/dashboard-data.service';
import { ModalPopupAlertComponent } from '../modal-popup-alert/modal-popup-alert.component';
import { OrderRole } from './order-role';
import { setting } from './table.config'
declare const $;

@Component({
    selector: 'app-user-managment',
    templateUrl: './user-role-managment.component.html',
    styleUrls: ['./user-role-managment.component.css']
})
export class UserRoleManagmentComponent implements OnInit, AfterViewInit {

    public toggle: any = {
        fullbox: false,
        editbox: true,
        createbox: true,
        alertBox: {
            title: "",
            body: "",
            compliteMsg: ""
        }
    }
    public createUser: boolean = true;
    public orderRequests: OrderRole[] = [];
    public source: LocalDataSource = new LocalDataSource();
    public customers: FormGroup;
   public url: string = "https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/UserRole";
   //public url: string = "http://localhost:58905/api/UserRole";
    public getUrl: string = this.url.concat("/GetDetails");
    public postUrl: string = this.url.concat("/AddRole");
    public editUrl: string = this.url.concat("/EditRole");
    public deleteUrl: string = this.url.concat("/Delete");
    public settings: object = setting;
    public deleteMsg: boolean;
    private deleteTemp: any = {
        title: "Delete Role",
        bodyAlert: "Are you sure you want to delete...?",
        btnColor: "red",
      btnName: "DELETE",
      compliteMsg: "Role is deleted successfully"
    }

  public alertTem: any = {
    alertmassage: null,
    alertColor: null
  }


   @ViewChild(CreateRoleComponent) creatUserSource: any;
  @ViewChild(EditRoleComponent) editUserSource: any;
  @ViewChild(MOdalPopupComponent) showData: any;
  @ViewChild(ModalPopupAlertComponent) sendAlertData: any;


    constructor(public http: Http, private _dataSource: DataSourceService, private fb: FormBuilder) {
        // this.source = new ServerDataSource(http, { endPoint: this.getUrl });
        //this.source = new ServerDataSource(http, { endPoint: "http://localhost:4545/userRole" });
        //this._dataSource.getOrderRequests(this.getUrl);
      this.sourceDataCall()
  }

  ngAfterViewInit(){
    $('.preloaderTable tbody tr td').html("<div class='block-width fa fa-spinner fa-pulse text-center fa-5x'></div>");
  }

  ngOnInit() {
    this._dataSource.change.subscribe((data) => {
      if (!data) {
        this.deleteTemp.compliteMsg = "Role Cannot Deleted.!";
      } else {
        this.deleteTemp.compliteMsg = "Role is deleted successfully";
      }
      this.sourceDataCall();
    })
        this.source.refresh();
        this.customers = this.fb.group({
            roleName: [''],
            user_Name: [''],
          pagePermissionsList: [''],
            landing_Page: ['']
        });
        this.creatUserSource.postUrl = this.postUrl;
      this.editUserSource.editUrl = this.editUrl;
      this.showData.templateData = this.deleteTemp;
    }

  crEmit(eve: any)
  {
    this.toggle.fullbox = eve.fullbox;
    this.toggle.editbox = eve.editbox;
    this.toggle.createbox = eve.createbox;
    if (eve.formName) { this.sendAlertData.templateDataLoad = eve.formName; }
    this.source.refresh();
  }

  sourceDataCall() {
    this._dataSource.getAllData(this.getUrl).toPromise().then(data => {
      this.source.load(data);
        this.source.refresh();
        this.source.reset();
        $('#tableCount').html(this.source.count())
    })
  }

    openCreateUers() {
        if (!this.toggle.fullBox) {
            this.toggle.fullbox = !this.toggle.fullbox
            this.toggle.createbox = !this.toggle.createbox
        };
        this.creatUserSource.toggleCU = this.toggle;
        this.editUserSource.toggleED = this.toggle;
    }

    editUersFun() {
        if (!this.toggle.fullBox) {
            this.toggle.fullbox = !this.toggle.fullbox
            this.toggle.editbox = !this.toggle.editbox
        };
        this.creatUserSource.toggleCU = this.toggle;
        this.editUserSource.toggleED = this.toggle;
    }

  onSearch(query: any) {
    debugger;
    //var name = query.pagePermission[0].name;
        if(!query){
            this.source.setFilter([])
            $('#tableCount').html(this.source.count())
        } else {
          if (query.pagePermission !== null && query.pagePermission !== undefined) {
            let  qpp  =  [];
            for (let  i  =  0;  i  <  query.pagePermission.length;  i++) {
              qpp.push(query.pagePermission[i].name);
            }
            query.pagePermission  =  qpp;
          } 
            this.source.setFilter([
              {
                    field: 'roleName',
                    search: query.roleName ? query.roleName : ""
                },
                {
                  field: 'pagePermissionsList',
                  search: query.pagePermission ? query.pagePermission : "",
                  filter: this.pagePermissionFilter
                }
            ], false,
            ).onChanged().subscribe(() => {
              $('#tableCount').html(this.source.count())
            });
        }
  }

  pagePermissionFilter(val?:  any,  search?:  string) {
    for (let  i  in  val) {
      if (search.indexOf(val[i])  >  -1) {
        return  true;
      }
    }
  } 

    getOrderRequests() {
        this._dataSource.getOrderRequests(this.getUrl)
            .then((orderRequests) => {
                this.orderRequests = orderRequests;
              this.source.load(orderRequests);
              this.source.refresh();
            });
    }

    //onCreate(event: any) {
    //    this.creatUserSource.openSource(this.source);
    //    this.source.refresh();
    //}

    //onDelete(orderRequest: any) {
    //    let url = `${this.deleteUrl}/${orderRequest.data.rolename}`;
    //    this._dataSource.delete(orderRequest.data, url)
    //        .then(() => {
    //            this.orderRequests = this.orderRequests;
    //        });
    //    this.source.remove(orderRequest.data);
    //    this.source.refresh();
    //}

  alertCall() {
    debugger;
        this.sendAlertData.templateDataLoad = this.deleteTemp;
        $("#alertPopup").modal("show");
    }

  deleteConf(orderRequest: any) {
    debugger;
    let url = `${this.deleteUrl}/${orderRequest.data.roleName}`;
    this._dataSource.delete(orderRequest.data, url)
      .then(() => {
        this.orderRequests = this.orderRequests;
      });
    this._dataSource.change.subscribe((data) => {
      debugger;
      if (data) {
        this.source.remove(orderRequest.data);
      }
      this.alertCall();
    })
  }

  onNotify(message: string): void {
    debugger
    let orderData = $('#confirmationPopup').data('deleteObj');
    this.deleteConf(orderData)
  }

  onDelete(orderRequest: any) {
    debugger;
    $('#confirmationPopup').data('deleteObj', orderRequest).modal();
  }

    onSave(event: any) {
        this.editUersFun();
        this._dataSource.setDetails(event.data);
        this.editUserSource.openSource(this.source);
        this.source.refresh();
    }
}
