import { Component, OnInit, Input } from '@angular/core';
declare const $;

@Component({
    selector: 'modal-popup-alert',
    templateUrl: './modal-popup-alert.component.html',
    styleUrls: ['./modal-popup-alert.component.css']
})

export class ModalPopupAlertComponent implements OnInit {

    public templateDataLoad: any = {
        title: "",
        body:"",
        compliteMsg: ""
    };

    constructor(){

    }

    ngOnInit(){
        
    }

}
