import { Component, OnInit } from '@angular/core';
import { DataSourceService } from '../../services/dashboard-data.service';
import { Http } from '@angular/http';

@Component({
  selector: 'app-events-mapping',
  templateUrl: './events-mapping.component.html',
  styleUrls: ['./events-mapping.component.css']
})
export class EventsMappingComponent implements OnInit {
   // public manageShow: boolean = false;
    public mappingShow: boolean = false;
    public manageMappingShow: boolean = true;
    public dropDownValues: any;
    public eventValues: any[];
    public seasonValues: any[];

    private url = 'https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/Event/Get';
    
    constructor(public http: Http) { }

    createMapBtn() {
        this.manageMappingShow = !this.manageMappingShow;
        this.mappingShow = !this.mappingShow;       
    }

    ngOnInit() {

  }
}
