import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-postion',
    templateUrl: './postion.component.html',
    styleUrls: ['./postion.component.css']
})
export class PostionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
