import { Component, OnInit, ViewChild, Input, Output, AfterViewInit  } from '@angular/core';
import { Http } from '@angular/http';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { CreateEventComponent } from './create-events/create-events.component'
import { FilterEventComponent } from './filter-events/filter-events.component'
import { MOdalPopupComponent } from '../modal-popup/modal-popup.component'
import { ModalPopupAlertComponent } from '../modal-popup-alert/modal-popup-alert.component'
import { EditEventComponent } from './edit-events/edit-events.component'
import { DataSourceService } from '../../services/dashboard-data.service';
import { EventRequest } from './event-request';
import { setting } from './table.config'
import { SimpleChange } from '@angular/core/src/change_detection/change_detection_util';
declare const $;

@Component({
    selector: 'app-event-criteria',
    templateUrl: './events-criteria.component.html',
    styleUrls: ['./events-criteria.component.css']
})
export class EventsCriteriaComponent implements OnInit, AfterViewInit  {

    public toggle: any = {
        fullbox: false,
        editbox: true,
        createbox: true,
        alertBox: {
            title: "",
            body: "",
            compliteMsg: ""
        }
    }
    public createUser: boolean = true;
    public orderRequests: EventRequest[] = [];
    public source: LocalDataSource = new LocalDataSource();
    public confirm: boolean = false;
    // public url: string = "https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/User/";
    public url: string = "https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/User";
    //public url: string = "http://localhost:58905/api/User";
    public getUrl: string = this.url.concat("/Get");
    public postUrl: string = this.url.concat("/Post");
    public editUrl: string = this.url.concat("/Edit");
    public deleteUrl: string = this.url.concat("/Delete");
    public settings: object = setting;

    private deleteTemp: any = {
        title: "Delete Event",
        bodyAlert: "Are you sure you want to delete...?",
        btnColor: "red",
        btnName: "DELETE",
        compliteMsg: "Event is deleted successfully"
    }

    public alertTem: any = {
        alertmassage: null,
        alertColor: null
    }
    
    @ViewChild(CreateEventComponent) creatUserSource: any;
    @ViewChild(EditEventComponent) editUserSource: any;
    @ViewChild(MOdalPopupComponent) showData: any;
    @ViewChild(ModalPopupAlertComponent) sendAlertData: any;
    
    constructor(public http: Http, private _dataSource: DataSourceService, private fb: FormBuilder) {
      this.sourceDataCall()
    }
  ngAfterViewInit() {
    $('.preloaderTable tbody tr td').html("<div class='block-width fa fa-spinner fa-pulse text-center fa-5x'></div>");
  }
  
  ngOnInit() {
    
    this._dataSource.change.subscribe((data) => {
      if (data) {
        this.sourceDataCall()
      }
    })
    this.creatUserSource.postUrl = this.postUrl;
    this.editUserSource.editUrl = this.editUrl;
    this.showData.templateData = this.deleteTemp;
  }

  sourceDataCall() {
    this._dataSource.getAllData(this.getUrl).toPromise().then(data => {
      this.source.load(data);
      this.source.refresh()
        this.source.reset();
        $('#tableCount').html(this.source.count())
    })
  }

  crEmit(eve: any) {
      this.toggle.fullbox = eve.fullbox;
      this.toggle.editbox = eve.editbox;
      this.toggle.createbox = eve.createbox;
      if(eve.formName){
          this.sendAlertData.templateDataLoad = eve.formName;
      }
  }

  openCreateUers() {
    if (!this.toggle.fullBox) {
      this.toggle.fullbox = !this.toggle.fullbox
      this.toggle.createbox = !this.toggle.createbox
    };
    this.creatUserSource.toggleCU = this.toggle;
    this.editUserSource.toggleED = this.toggle;
  }

  editUersFun() {
    debugger;
    if (!this.toggle.fullBox) {
      this.toggle.fullbox = !this.toggle.fullbox
      this.toggle.editbox = !this.toggle.editbox
    };
    this.creatUserSource.toggleCU = this.toggle;
    this.editUserSource.toggleED = this.toggle;
  }

  onSearch(query: any) {
    debugger;
        if(!query){            
          this.source.setFilter([])
          $('#tableCount').html(this.source.count())
        } else {
          if (query.stations !== undefined && query.stations !== null) {
            let qpp = [];
            for (let i = 0; i < query.stations.length; i++) {
              qpp.push(query.stations[i].name);
            }
            query.stations = qpp;
          }
            this.source.setFilter([
                {
                    field: 'userName',
                    search: query.userName ? query.userName : ""
                },
                {
                    field: 'firstName',
                    search: query.firstName ? query.firstName : ""
                },
                {
                    field: 'lastName',
                    search: query.lastName ? query.lastName : ""
                },
                {
                    field: 'userRole',
                    search: query.userRole ? query.userRole : ""
              },
              {
                field: 'stationList',
                search: query.stations ? query.stations : "",
                filter: this.stationsFilter
              }
            ], false,
            ).onChanged().subscribe(() => {
              $('#tableCount').html(this.source.count())
            });
        }
  }

  stationsFilter(val?: any, search?: string) {
    for (let i in val) {
      if (search.indexOf(val[i]) > -1) {
        return true;
      }
    }
  }
  

    alertCall(){
        this.sendAlertData.templateDataLoad = this.deleteTemp;
        $("#alertPopup").modal("show");
    }

    deleteConf(orderRequest: any){
        debugger;
        let url = `${this.deleteUrl}/${orderRequest.data.userName}`;
        this._dataSource.delete(orderRequest.data, url)
            .then(() => {
                this.orderRequests = this.orderRequests;
            })
        this.source.remove(orderRequest.data);
		this.source.refresh();
        this.alertCall();
    }

    onNotify(message:string):void {
        debugger
        let orderData = $('#confirmationPopup').data('deleteObj');
        this.deleteConf(orderData)
    }
    
    onDelete(orderRequest: any) {
        debugger;
        $('#confirmationPopup').data('deleteObj', orderRequest).modal();
    }
    
  onSave(event: any) {
    debugger;
        this.editUersFun();
        this._dataSource.setDetails(event.data);
        this.editUserSource.openSource(this.source);
        this.source.refresh();
    }
}
