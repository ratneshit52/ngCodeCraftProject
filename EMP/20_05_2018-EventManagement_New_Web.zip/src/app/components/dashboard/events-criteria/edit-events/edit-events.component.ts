import { Component, ViewChild, Input, OnInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Http } from '@angular/http';
import { EventRequest } from '../event-request';
import { DataSourceService } from '../../../services/dashboard-data.service';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { MenuItem } from 'primeng/api';
declare const $;


@Component({
    selector: 'edit-event',
    templateUrl: '../create-events/create-events.component.html',
    styleUrls: ['../create-events/create-events.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class EditEventComponent implements OnInit {

    revenueCodeValues3: any;
    revenueCodeValues2: any;
    revenueCodeValues1: any;
    stationValues: any;
    orderTypevalues: any;
    breakCodevalues: any;
    dropDownValues: any;
    transactionTypevalues: any[] = [{name: 'Cash'}, {name: 'Trade'}];
    public criteriaShow: boolean = false;
    Inventorylevels: any[] = [1,2,3,4,5,6];

    orderRequests: EventRequest[] = [];
    public userDetails: FormGroup;
    public data: any;
    public toggleED: any;
    public editUrl: string;
    
    public source: LocalDataSource = new LocalDataSource();
    @Input() orderRequest: EventRequest;
    @Output() editUserMang = new EventEmitter<string>();

    public formName: any = {
        title: "UPDATE EVENT DETAILS",
        subBtnName: "UPDATE",
        disabledVal: "disabled",
        compliteMsg: "Upadate Event Successfull."
    }

    constructor(private fb: FormBuilder, private appService: DataSourceService, public http: Http) {}

    ngOnInit(): void {
        this.userDetails = this.fb.group({
            eventName: ['', Validators.required],
            transactionType: ['', Validators.required],
            reportingPeriodFrom: ['', Validators.required],
            reportingPeriodTo: ['', Validators.required],
            breakCodes: ['', Validators.required],
            seasonName: ['', Validators.required],
            revenueCodes1: ['', Validators.required],
            revenueCodes2: ['', Validators.required],
            revenueCodes3: ['', Validators.required],
            station: ['', Validators.required],
            eventPointFrom: ['', Validators.required],
            eventPointTo: ['', Validators.required],
            orderType: ['', Validators.required],
            inventoryLevels: [''],
      });
    }

  arrayfunction() {
    this.http.get("https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/Event/Get")
      .subscribe(response => {
        debugger;
        this.dropDownValues = response.json();
        if(this.dropDownValues !== null || this.dropDownValues !== undefined) {
          this.breakCodevalues = this.dropDownValues["BreakCodes"].map(e => { return {name: e}});
          this.orderTypevalues = this.dropDownValues["OrderType"].map(e => { return {name: e}});
          this.stationValues = this.dropDownValues["Stations"].map(e => { return {name: e}});
          this.revenueCodeValues1 = this.dropDownValues["RevenueCodes1"].map(e => { return {name: e}});
          this.revenueCodeValues2 = this.dropDownValues["RevenueCodes2"].map(e => { return {name: e}});
          this.revenueCodeValues3 = this.dropDownValues["RevenueCodes3"].map(e => { return {name: e}});
          //this.transactionTypevalues = this.dropDownValues["TransactionTypes"].map(e => { return {name: e}});
        }
      });
  }

    open() {
        this.data = this.appService.getDetails();
        this.stationValues = this.data.stationList;
        this.arrayfunction();
        this.userDetails = this.fb.group({
            eventName: [this.data.eventName],
            transactionType: [this.data.transactionType],
            reportingPeriodFrom: [this.data.reportingPeriodFrom],
            reportingPeriodTo: [this.data.reportingPeriodTo],
            breakCodes: [this.data.breakCodes],
            seasonName: [this.data.seasonName],
            revenueCodes1: [this.data.revenueCodes1],
            revenueCodes2: [this.data.revenueCodes2],
            revenueCodes3: [this.data.revenueCodes3],
            station: [this.data.station],
            eventPointFrom: [this.data.eventPointFrom],
            eventPointTo: [this.data.eventPointTo],
            orderType: [this.data.orderType],
            inventoryLevels: [this.data.inventoryLevels]
        })
    }

    openSource(source: any) {
        this.source = source;
        this.open();
    }

    emitToggleData(value: any) {
        this.editUserMang.emit(value)
    }

    onSubmit({ value, valid }: { value: EventRequest, valid: boolean }) {
        this.edit({ value, valid });
        //this.close();
    }

    close() {
        if (!this.toggleED.editbox) {
            this.toggleED.editbox = !this.toggleED.editbox;
            this.toggleED.fullbox = !this.toggleED.fullbox;
        }
        this.emitToggleData(this.toggleED);
        this.userDetails.reset()
    }

    alertCall(){
        this.toggleED.formName = this.formName;
        $("#alertPopup").modal("show");
        this.close()
    }

    edit({ value, valid }: { value: EventRequest, valid: boolean }): void {
        let result = JSON.stringify(value);
        if (!result) {
            return;
        }
        this.appService.update(value, this.editUrl)
            .then(() => {
                this.source.update(this.data, value);
                this.source.refresh();
                this.alertCall()
                return null;
            });
        //this.source.update(this.data, value); no luck here as well
    }
}
