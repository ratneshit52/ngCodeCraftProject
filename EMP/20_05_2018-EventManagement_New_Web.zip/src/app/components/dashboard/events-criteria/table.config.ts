let userrole: any;
//if (this.settings.columns["stationList"].hasOwnProperty("show")) {
//  if (this.settings.columns["stationList"].show == false) {
//    delete this.settings.columns["stationList"];
//  }
//}
export const setting = {
    "mode": "external",
    "actions": {
        "add": true,
        "position": "right"
    },
    "edit": {
        "inputClass": "form-control input-sm",
        "editButtonContent": "<img src='../../../../assets/images/edit.png'>",
        "saveButtonContent": "<i class='glyphicon glyphicon-ok' aria-hidden='true'></i>",
        "cancelButtonContent": "<i class='glyphicon glyphicon-remove' aria-hidden='true'></i>",
        "confirmSave": true
    },
    "delete": {
        "deleteButtonContent": "<img src='../../../../assets/images/delete.png'>",
        "confirmDelete": true
    },
    "add": {
        "inputClass": "form-control input-sm",
        "addButtonContent": "<label class='label label-info'>Create User</label>",
        "createButtonContent": "<i class='glyphicon glyphicon-pencil' aria-hidden='true'></i>",
        "cancelButtonContent": "<i class='glyphicon glyphicon-remove' aria-hidden='true'></i>",
        "confirmCreate": true
    },
    "columns": {
        "userName": {
            "title": "Event Name",
        },
        "firstName": {
            "title": "Season Name"
        },
        "lastName": {
            "title": "Start Date"
        },
        "userRole": {
            "title": "End Date"
        },
        "createdBy": {
            "title": "Created By"
        },
        "updatedBy": {
            "title": "Updated By"
        },
        "updated_Date": {
            "title": "Last Updated"
        },
    },
    "attr": {
      "class": "table table-font-normal startFilterExternal preloaderTable"
    }
}
