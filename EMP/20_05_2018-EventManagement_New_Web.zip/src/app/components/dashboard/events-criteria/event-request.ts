export class EventRequest {
    eventName: any;
    transactionType: any;
    reportingPeriodFrom: any;
    reportingPeriodTo: any;
    breakCodes: any;
    seasonName: any;
    revenueCodes1: any;
    revenueCodes2: any;
    revenueCodes3: any;
    station: any;
    eventPointFrom: any;
    eventPointTo: any;
    orderType: any;
    inventoryLevels?: any;
    constructor(eventName: any, transactionType: any, reportingPeriodFrom: any, reportingPeriodTo: any, breakCodes: any, seasonName: any, revenueCodes1: any, revenueCodes2: any, revenueCodes3: any, station: any, eventPointFrom: any, eventPointTo: any, orderType: any, inventoryLevels: any) {
        this.eventName = eventName;
        this.transactionType = transactionType;
        this.reportingPeriodFrom = reportingPeriodFrom;
        this.reportingPeriodTo = reportingPeriodTo;
        this.breakCodes = breakCodes;
        this.seasonName = seasonName;
        this.revenueCodes1 = revenueCodes1;
        this.revenueCodes2 = revenueCodes2;
        this.revenueCodes3 = revenueCodes3;
        this.station = station;
        this.eventPointFrom = eventPointFrom;
        this.eventPointTo = eventPointTo;
        this.orderType = orderType;
        this.inventoryLevels = inventoryLevels;
    }
}
