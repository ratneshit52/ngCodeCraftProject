import { Component, ViewChild, Input, OnInit, Output, EventEmitter, ViewEncapsulation  } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Http } from '@angular/http'
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { AccordionModule } from 'primeng/accordion';
import { MenuItem } from 'primeng/api';
import { debounce } from 'rxjs/operators/debounce';
declare const $;

@Component({
  selector: 'filter-event',
  templateUrl: 'filter-events.component.html',
  styleUrls: ['filter-events.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class FilterEventComponent implements OnInit {

    seasonValues: any;
    eventValues: any;
    dropDownValues: any;
    
    public userDetails: FormGroup;
    public data: any;
    public source: LocalDataSource = new LocalDataSource();
    @Output() messageEvent = new EventEmitter<string>();

    private url = 'https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/User/Details'
    //private url = 'http://localhost:58905/api/User/GetRole';

    public formName: any = {
        "title": "Search Criteria",
        "subBtnName": "SEARCH"
    }

    
  constructor(private fb: FormBuilder, private http: Http) {
    }

  ngOnInit(): void {
    this.http.get(this.url)
      .subscribe(response => {
        this.dropDownValues = response.json();
        this.eventValues = this.dropDownValues["EventNames"];
        this.seasonValues = this.dropDownValues["SeasonNames"];
          
      });
        this.userDetails = this.fb.group({
          eventValues: [null],
          seasonValues: [null]
        });
    }

  onSubmit(dataD: any) {
    debugger;
        const isEmpty = Object.keys(dataD.value).map((k) => dataD.value[k]).every(x => (x === null || x === '' || x === undefined));
        if (isEmpty) {
            this.onRest()
            return true;
        }
        this.messageEvent.emit(dataD.value);
    }

    onRest() {
        this.messageEvent.emit(null);
    }

}
