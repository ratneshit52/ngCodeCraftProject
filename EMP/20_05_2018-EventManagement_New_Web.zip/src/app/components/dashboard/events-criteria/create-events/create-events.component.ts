import { Component, ViewChild, Input, OnInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Http } from '@angular/http';
import { EventRequest } from '../event-request';
import { DataSourceService } from '../../../services/dashboard-data.service';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { AccordionModule } from 'primeng/accordion';
import { MenuItem } from 'primeng/api';
declare const $;

@Component({
    selector: 'create-event',
    templateUrl: 'create-events.component.html',
    styleUrls: ['create-events.component.css'],
    encapsulation: ViewEncapsulation.None
})
export class CreateEventComponent implements OnInit {

    revenueCodeValues3: any;
    revenueCodeValues2: any;
    revenueCodeValues1: any;
    stationValues: any;
    orderTypevalues: any;
    breakCodevalues: any;
    dropDownValues: any;
    transactionTypevalues: any[] = [{name: 'Cash'}, {name: 'Trade'}];
    public criteriaShow: boolean = false;
    Inventorylevels: any[] = [1,2,3,4,5,6];

    orderRequests: EventRequest[] = [];
    public userDetails: FormGroup;
    public toggleCU: any;
    public postUrl: string;
    public source: LocalDataSource = new LocalDataSource();

    @Input() orderRequest: EventRequest;
    @Output() toggleScreenCU = new EventEmitter<string>();

    public formName: any = {
        "title": "CREATE EVENT",
        "subBtnName": "SAVE",
        disabledVal: null,
        "compliteMsg": "Create Event Successfull."
    }

    constructor(private fb: FormBuilder, private appService: DataSourceService, public http: Http) {}

    ngOnInit(): void {
      this.appService.change.subscribe((data) => {
        debugger;
        if (!data) {
          this.formName.compliteMsg = "Event Already Exist...!";
        } else {
          this.formName.compliteMsg = "Create Event Successfull";
        }

      })
      this.userDetails = this.fb.group({
        eventName: ['', Validators.required],
        transactionType: ['', Validators.required],
        reportingPeriodFrom: ['', Validators.required],
        reportingPeriodTo: ['', Validators.required],
        breakCodes: ['', Validators.required],
        seasonName: ['', Validators.required],
        revenueCodes1: ['', Validators.required],
        revenueCodes2: ['', Validators.required],
        revenueCodes3: ['', Validators.required],
        station: ['', Validators.required],
        eventPointFrom: ['', Validators.required],
        eventPointTo: ['', Validators.required],
        orderType: ['', Validators.required],
        inventoryLevels: [''],
      });
      this.createDropDownReq();
    }

    openSource(source: any) {
      this.source = source;
    }

    emitToggleData(value: any) {
        this.toggleScreenCU.emit(value)
    }

    onSubmit({ value, valid }: { value: EventRequest, valid: boolean }) {
      debugger;
      this.add({ value, valid });
    }

    close() {
        if (!this.toggleCU.createbox) {
            this.toggleCU.createbox = !this.toggleCU.createbox;
            this.toggleCU.fullbox = !this.toggleCU.fullbox;
        }
        this.emitToggleData(this.toggleCU);
        this.userDetails.reset();
        this.criteriaShow = !this.criteriaShow;
    }

    alertCall() {
      this.toggleCU.formName = this.formName;
      $("#alertPopup").modal("show");
      this.close()
    }

    add({ value, valid }: { value: EventRequest, valid: boolean }): void {
      debugger;
        let result = JSON.stringify(value);
        if (!result) {
            this.userDetails.reset()
            return;
        }
        this.appService.create(value, this.postUrl)
            .then(orderRequest => {
              debugger;
              console.log(orderRequest)
                  this.orderRequests.push(orderRequest);
                  this.source.add(orderRequest);
                  this.source.reset();
                  this.userDetails.reset();
                  this.alertCall();
            });
     }

     /*Create Form Input Filed Dropdown*/
     createDropDownReq(){
      this.http.get("https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/Event/Get")
      .subscribe(response => {
        debugger;
        this.dropDownValues = response.json();
        if(this.dropDownValues !== null || this.dropDownValues !== undefined) {
          this.breakCodevalues = this.dropDownValues["BreakCodes"].map(e => { return {name: e}});
          this.orderTypevalues = this.dropDownValues["OrderType"].map(e => { return {name: e}});
          this.stationValues = this.dropDownValues["Stations"].map(e => { return {name: e}});
          this.revenueCodeValues1 = this.dropDownValues["RevenueCodes1"].map(e => { return {name: e}});
          this.revenueCodeValues2 = this.dropDownValues["RevenueCodes2"].map(e => { return {name: e}});
          this.revenueCodeValues3 = this.dropDownValues["RevenueCodes3"].map(e => { return {name: e}});
          //this.transactionTypevalues = this.dropDownValues["TransactionTypes"].map(e => { return {name: e}});
        }
      });
     }

    showCriteriaBtn() {
      this.criteriaShow = !this.criteriaShow;
    }
}
