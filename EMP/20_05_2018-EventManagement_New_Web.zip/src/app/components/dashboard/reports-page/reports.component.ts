import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { DataSourceService } from '../../services/dashboard-data.service';
import { Http } from '@angular/http';
import { AccordionModule } from 'primeng/accordion';
import { MenuItem } from 'primeng/api';


interface DropDown {
  name: string
}

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ReportsComponent implements OnInit {

  //private url = 'http://localhost:58905/api/Report/get';
  private url = 'https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/Report/get';

  public dropDownValues: any;
  public eventValues: any[];
  public seasonValues: any[];
  public stationValues: any[];
  public salesRegionValues: any[] = ['local','National','xxx'];
  public reportTypes: string[] = ["Calendar", "Consolidated Report", "Network", "Sales Region", "Season", "Spot Detail Report"];

  station: DropDown[] = [];
  Stations: DropDown[];

  salesRegion: DropDown[] = [];
  SalesRegions: DropDown[];

  constructor(public http: Http) { }

  ngOnInit() {
    this.http.get(this.url)
      .subscribe(response => {
        this.dropDownValues = response.json();
        this.eventValues = this.dropDownValues["EventNames"];
        this.seasonValues = this.dropDownValues["SeasonNames"];
        this.stationValues = this.dropDownValues["StationNames"];
        this.salesRegionValues = this.dropDownValues["SalesRegionNames"];

        this.stationValues.forEach(e => {
          this.station.push({
            name: e
          });
          this.Stations = this.station;
        })
        this.salesRegionValues.forEach(e => {
          this.salesRegion.push({
            name: e
          });
          this.SalesRegions = this.salesRegion;
        })

      });
  }

  selectName(){
    
  }

}
