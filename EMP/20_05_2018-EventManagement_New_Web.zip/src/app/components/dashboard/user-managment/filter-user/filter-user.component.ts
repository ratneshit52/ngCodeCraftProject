import { Component, ViewChild, Input, OnInit, Output, EventEmitter, ViewEncapsulation  } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Http } from '@angular/http'
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { AccordionModule } from 'primeng/accordion';
import { MenuItem } from 'primeng/api';
import { debounce } from 'rxjs/operators/debounce';
declare const $;
interface DropDown {
  name: string
}

@Component({
    selector: 'filter-user',
    templateUrl: 'filter-user.component.html',
  styleUrls: ['filter-user.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class FilterUserComponent implements OnInit {

    public userDetails: FormGroup;
    public data: any;
    public source: LocalDataSource = new LocalDataSource();
  @Output() messageEvent = new EventEmitter<string>();

  public roleValues: any[];
  public dropDownValues: any;
  public stationValues: any[];
  public userName: any;
  public firstName: any;
  public lastName: any;
  public userRole: any;
  public stations: any;
  station: DropDown[] = [];
  Stations: DropDown[];
  private url = 'https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/User/Details'
  //private url = 'http://localhost:58905/api/User/GetRole';

    public formName: any = {
        "title": "Search Criteria",
        "subBtnName": "SEARCH"
    }

    public products: any = [
        { "name": "Admin", "value": "Admin" },
        { "name": "Station Posting", "value": "Station Posting" },
        { "name": "Station Report", "value": "Station Report" },
        { "name": "Super User", "value": "Super User" }
    ]

  constructor(
    private fb: FormBuilder, private http: Http
    ) {
    }

  ngOnInit(): void {
    this.http.get(this.url)
      .subscribe(response => {
        this.dropDownValues = response.json();
        this.roleValues = this.dropDownValues["RoleNames"];
        this.stationValues = this.dropDownValues["Stations"];

        this.stationValues.forEach(e => {
          this.station.push({
            name: e
          });
          this.Stations = this.station;
        })
      });
        this.userDetails = this.fb.group({
            userName: [null],
            firstName: [null],
            lastName: [null],
          userRole: [null],
            stations: [null]
        });
    }

  onSubmit(dataD: any) {
    debugger;
        const isEmpty = Object.keys(dataD.value).map((k) => dataD.value[k]).every(x => (x === null || x === '' || x === undefined));
        if (isEmpty) {
            this.onRest()
            return true;
        }
        this.messageEvent.emit(dataD.value);
    }

    onRest() {
        this.messageEvent.emit(null);
    }

}
