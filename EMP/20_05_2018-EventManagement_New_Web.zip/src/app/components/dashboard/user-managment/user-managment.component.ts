import { Component, OnInit, ViewChild, Input, Output, AfterViewInit  } from '@angular/core';
import { Http } from '@angular/http';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { CreateUserComponent } from './creat-page/create-user.component'
import { FilterUserComponent } from './filter-user/filter-user.component'
import { MOdalPopupComponent } from '../modal-popup/modal-popup.component'
import { ModalPopupAlertComponent } from '../modal-popup-alert/modal-popup-alert.component'
import { EditUserComponent } from './edit-user/edit-user.component'
import { DataSourceService } from '../../services/dashboard-data.service';
import { OrderRequest } from './order-request';
import { setting } from './table.config'
import { SimpleChange } from '@angular/core/src/change_detection/change_detection_util';
declare const $;

@Component({
    selector: 'app-user-managment',
    templateUrl: './user-managment.component.html',
    styleUrls: ['./user-managment.component.css']
})
export class UserManagmentComponent implements OnInit, AfterViewInit  {

    public toggle: any = {
        fullbox: false,
        editbox: true,
        createbox: true,
        alertBox: {
            title: "",
            body: "",
            compliteMsg: ""
        }
    }
    public createUser: boolean = true;
    public orderRequests: OrderRequest[] = [];
    public source: LocalDataSource = new LocalDataSource();
    public customers: FormGroup;
    public confirm: boolean = false;
    // public url: string = "https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/User/";
   public url: string = "https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/User";
    //public url: string = "http://localhost:58905/api/User";
    public getUrl: string = this.url.concat("/Get");
    public postUrl: string = this.url.concat("/Post");
    public editUrl: string = this.url.concat("/Edit");
    public deleteUrl: string = this.url.concat("/Delete");
    public settings: object = setting;

    private deleteTemp: any = {
        title: "Delete User",
        bodyAlert: "Are you sure you want to delete...?",
        btnColor: "red",
        btnName: "DELETE",
        compliteMsg: "User is deleted successfully"
    }

    public alertTem: any = {
        alertmassage: null,
        alertColor: null
    }
    
    @ViewChild(CreateUserComponent) creatUserSource: any;
    @ViewChild(EditUserComponent) editUserSource: any;
    @ViewChild(MOdalPopupComponent) showData: any;
    @ViewChild(ModalPopupAlertComponent) sendAlertData: any;
    
    constructor(public http: Http, private _dataSource: DataSourceService, private fb: FormBuilder) {
        //this.source = new ServerDataSource(http, { endPoint: this.getUrl });
      //this.source = new ServerDataSource(http, { endPoint: "http://localhost:3000/dbdata" });
      //this._dataSource.getOrderRequests(this.getUrl);
      this.sourceDataCall()
    }
  ngAfterViewInit() {
    $('.preloaderTable tbody tr td').html("<div class='block-width fa fa-spinner fa-pulse text-center fa-5x'></div>");
    this.hideColumn("hideColumn");
  }
  hideColumn(className:  string) {
    let  machCount  =  [];
    let  colCount  =  0;
    $('ng2-smart-table table tr:nth-child(1) th').each(function  () {
      console.log($(this).hasClass(className));
      if  ($(this).attr('colspan')) {
        colCount  +=  +$(this).attr('colspan');
        if ($(this).hasClass(className)) {
          machCount.push(colCount);
        }
      }  else  {
        colCount++;
        if ($(this).hasClass(className)) {
          machCount.push(colCount);
        }
      }
    });
    this.hideColumnLoop(machCount);
  }
  hideColumnLoop(rval:  any[]) {
    let  styleCode  =  '<style type="text/css">';
    for (let  i = 0;  i  <  rval.length;  i++) {
      styleCode  +=  'ng2-smart-table table th:nth-child(' +  rval[i]  + '), ng2-smart-table table td:nth-child(' +  rval[i]  + ') {display: none}';
    }
    styleCode  +=  '</style>';
    debugger;
    $("head").append(styleCode)
  } 
  ngOnInit() {
    
    this._dataSource.change.subscribe((data) => {
      if (data) {
        this.sourceDataCall()
      }
    })
        this.customers = this.fb.group({
            userName: [''],
            firstName: [''],
            lastName: [''],
            userRole: [''],
            stationList: ['']
        });
        this.creatUserSource.postUrl = this.postUrl;
        this.editUserSource.editUrl = this.editUrl;
    this.showData.templateData = this.deleteTemp;
  }

  sourceDataCall() {
    this._dataSource.getAllData(this.getUrl).toPromise().then(data => {
      this.source.load(data);
      this.source.refresh()
        this.source.reset();
        $('#tableCount').html(this.source.count())
    })
  }

    crEmit(eve: any) {
        this.toggle.fullbox = eve.fullbox;
        this.toggle.editbox = eve.editbox;
        this.toggle.createbox = eve.createbox;
        if(eve.formName){
            this.sendAlertData.templateDataLoad = eve.formName;
        }
    }

    openCreateUers() {
        if (!this.toggle.fullBox) {
            this.toggle.fullbox = !this.toggle.fullbox
            this.toggle.createbox = !this.toggle.createbox
        };
        this.creatUserSource.toggleCU = this.toggle;
        this.editUserSource.toggleED = this.toggle;
    }

  editUersFun() {
    debugger;
        if (!this.toggle.fullBox) {
            this.toggle.fullbox = !this.toggle.fullbox
            this.toggle.editbox = !this.toggle.editbox
        };
        this.creatUserSource.toggleCU = this.toggle;
        this.editUserSource.toggleED = this.toggle;

    }

  onSearch(query: any) {
    debugger;
        if(!query){            
          this.source.setFilter([])
          $('#tableCount').html(this.source.count())
        } else {
          if (query.stations !== undefined && query.stations !== null) {
            let qpp = [];
            for (let i = 0; i < query.stations.length; i++) {
              qpp.push(query.stations[i].name);
            }
            query.stations = qpp;
          }
            this.source.setFilter([
                {
                    field: 'userName',
                    search: query.userName ? query.userName : ""
                },
                {
                    field: 'firstName',
                    search: query.firstName ? query.firstName : ""
                },
                {
                    field: 'lastName',
                    search: query.lastName ? query.lastName : ""
                },
                {
                    field: 'userRole',
                    search: query.userRole ? query.userRole : ""
              },
              {
                field: 'stationList',
                search: query.stations ? query.stations : "",
                filter: this.stationsFilter
              }
            ], false,
            ).onChanged().subscribe(() => {
              $('#tableCount').html(this.source.count())
            });
        }
  }

  stationsFilter(val?: any, search?: string) {
    for (let i in val) {
      if (search.indexOf(val[i]) > -1) {
        return true;
      }
    }
  }

    getOrderRequests() {
        debugger;
        this._dataSource.getOrderRequests(this.getUrl)
            .then((orderRequests) => {
                this.orderRequests = orderRequests;
                this.source.load(orderRequests);
              this.source.refresh();
            });
    }

    alertCall(){
        this.sendAlertData.templateDataLoad = this.deleteTemp;
        $("#alertPopup").modal("show");
    }

    deleteConf(orderRequest: any){
        debugger;
        let url = `${this.deleteUrl}/${orderRequest.data.userName}`;
        this._dataSource.delete(orderRequest.data, url)
            .then(() => {
                this.orderRequests = this.orderRequests;
            })
        this.source.remove(orderRequest.data);
		this.source.refresh();
        this.alertCall();
    }

    onNotify(message:string):void {
        debugger
        let orderData = $('#confirmationPopup').data('deleteObj');
        this.deleteConf(orderData)
    }
    
    onDelete(orderRequest: any) {
        debugger;
        $('#confirmationPopup').data('deleteObj', orderRequest).modal();
    }



  onSave(event: any) {
    debugger;
        this.editUersFun();
        this._dataSource.setDetails(event.data);
        this.editUserSource.openSource(this.source);
        this.source.refresh();
    }
}
