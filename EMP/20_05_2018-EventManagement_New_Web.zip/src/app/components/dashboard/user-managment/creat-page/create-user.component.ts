import { Component, ViewChild, Input, OnInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { OrderRequest } from '../order-request';
import { DataSourceService } from '../../../services/dashboard-data.service';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { AccordionModule } from 'primeng/accordion';
import { MenuItem } from 'primeng/api';
import { Http } from '@angular/http';
declare const $;
interface DropDown {
  name: string
}

@Component({
    selector: 'create-user',
    templateUrl: 'create-user.component.html',
  styleUrls: ['create-user.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CreateUserComponent implements OnInit {

    orderRequests: OrderRequest[] = [];
    public userDetails: FormGroup;
    public toggleCU: any;
    public userName: any;
    public firstName: any;
    public lastName: any;
    public userRole: any;
    public stations: any;
  public postUrl: string;
  public roleValues: any[];
  public stationValues: any[];
  public dropDownValues: any;
  station: DropDown[] = [];
  Stations: DropDown[];
    private url = 'https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/User/Details';
    //private url = 'http://localhost:58905/api/User/Details';
    public source: LocalDataSource = new LocalDataSource();
    @Input() orderRequest: OrderRequest;
    @Output() toggleScreenCU = new EventEmitter<string>();

    public formName: any = {
        "title": "CREATE USER",
        "subBtnName": "SAVE",
        disabledVal: null,
        "compliteMsg": "Create User Successfull."
    }

    public products: any = [
        { "name": "Admin", "value": "Admin" },
        { "name": "Station Posting", "value": "Station Posting" },
        { "name": "Station Report", "value": "Station Report" },
        { "name": "Super User", "value": "Super User" }
  ]

  //public stations: any = [
  //  { "name": "CBS Digital", "value": "CBS Digital" },
  //  { "name": "Out-of-Home", "value": "Out-of-Home" },
  //  { "name": "WJZ-TV", "value": "WJZ-TV" },
  //  { "name": "KTXA-TV", "value": "KTXA-TV" }
  //]


    constructor(
        private fb: FormBuilder,
      private appService: DataSourceService, public http: Http
    ) {
     }

  ngOnInit(): void {
    this.appService.change.subscribe((data) => {
      debugger;
      if (!data) {
        this.formName.compliteMsg = "User Already Exist...!";
      } else {
        this.formName.compliteMsg = "Create User Successfull";
      }

    })
        this.userDetails = this.fb.group({
            userName: ['', Validators.required],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            userRole: ['', Validators.required],
            stations: ['', Validators.required]
      });

      this.http.get(this.url)
        .subscribe(response => {
          this.dropDownValues = response.json();
          this.roleValues = this.dropDownValues["RoleNames"];
          this.stationValues = this.dropDownValues["Stations"];
          
          this.stationValues.forEach(e => {
            this.station.push({
              name: e
            });
            this.Stations = this.station;
          })

        });
    }

    openSource(source: any) {
      this.source = source;
    }

    emitToggleData(value: any) {
        this.toggleScreenCU.emit(value)
    }

  onSubmit({ value, valid }: { value: OrderRequest, valid: boolean }) {
    debugger;
        this.add({ value, valid });
      //  this.close();
    }

    close() {
        if (!this.toggleCU.createbox) {
            this.toggleCU.createbox = !this.toggleCU.createbox;
            this.toggleCU.fullbox = !this.toggleCU.fullbox;
        }
        this.emitToggleData(this.toggleCU);
        this.userDetails.reset()
    }

  alertCall() {
      this.toggleCU.formName = this.formName;
      $("#alertPopup").modal("show");
      this.close()
  }

  add({ value, valid }: { value: OrderRequest, valid: boolean }): void {
    debugger;
        let result = JSON.stringify(value);
        if (!result) {
            this.userDetails.reset()
            return;
        }
        this.appService.create(value, this.postUrl)
          .then(orderRequest => {
            debugger;
            console.log(orderRequest)
                this.orderRequests.push(orderRequest);
                this.source.add(orderRequest);
                this.source.reset();
                this.userDetails.reset();
                this.alertCall();
            });
    }
}
