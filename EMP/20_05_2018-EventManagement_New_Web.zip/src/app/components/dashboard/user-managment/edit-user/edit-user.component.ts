import { Component, ViewChild, Input, OnInit, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { OrderRequest } from '../order-request';
import { DataSourceService } from '../../../services/dashboard-data.service';
import { Ng2SmartTableModule, LocalDataSource } from 'ng2-smart-table';
import { MenuItem } from 'primeng/api';
import { Http } from '@angular/http';
declare const $;
interface DropDown {
  name: string
}


@Component({
    selector: 'edit-user',
    templateUrl: '../creat-page/create-user.component.html',
  styleUrls: ['../creat-page/create-user.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class EditUserComponent implements OnInit {

    orderRequests: OrderRequest[] = [];
    public userDetails: FormGroup;
    public data: any;
    public toggleED: any;
    public userName: any;
    public firstName: any;
    public lastName: any;
    public userRole: any;
    public stations: any;
  public editUrl: string;
  public stationValues: any[];
  public roleValues: any[];
  public dropDownValues: any;
  station: DropDown[] = [];
  Stations: DropDown[];
   private url = 'https://cbseventmanagement-api-dot-thermal-wonder-200107.appspot.com/api/User/Details';
  //private url = 'http://localhost:58905/api/User/Details';
  public source: LocalDataSource = new LocalDataSource();
    @Input() orderRequest: OrderRequest;
    @Output() editUserMang = new EventEmitter<string>();

    public formName: any = {
        title: "UPDATE USER DETAILS",
        subBtnName: "UPDATE",
        disabledVal: "disabled",
        compliteMsg: "Upadate User Successfull."
    }

    public products: any = [
        { "name": "Admin", "value": "Admin" },
        { "name": "Station Posting", "value": "Station Posting" },
        { "name": "Station Report", "value": "Station Report" },
        { "name": "Super User", "value": "Super User" }
    ]

    constructor(
        private fb: FormBuilder,
      private appService: DataSourceService, public http: Http
    ) {

      
    }

    ngOnInit(): void {
        this.userDetails = this.fb.group({
            userName: ['', Validators.required],
            firstName: ['', Validators.required],
            lastName: ['', Validators.required],
            userRole: ['', Validators.required],
            stations: ['', Validators.required]
      });

      this.http.get(this.url)
        .subscribe(response => {
          this.dropDownValues = response.json();
          this.roleValues = this.dropDownValues["RoleNames"];
          this.stationValues = this.dropDownValues["Stations"];
          this.arrayfunction();
          this.Stations = this.station;
        });
  }

  arrayfunction() {
    this.station = [];
    this.stationValues.forEach(e => {
      this.station.push({
        name: e
      });
    })
  }

  open() {
    //debugger;
    this.data = this.appService.getDetails();
    this.stationValues = this.data.stationList;
    this.arrayfunction();
    //this.station = [];
    //this.stationValues.forEach(e => {
    //  this.station.push({
    //    name: e
    //  });     
    //})

    this.userDetails = this.fb.group({
      userName: [this.data.userName],
      firstName: [this.data.firstName],
      lastName: [this.data.lastName],
      userRole: [this.data.userRole],
      stations: [this.station]
        })
    }

    openSource(source: any) {
        this.source = source;
        this.open();
    }

    emitToggleData(value: any) {
        this.editUserMang.emit(value)
    }

    onSubmit({ value, valid }: { value: OrderRequest, valid: boolean }) {
        this.edit({ value, valid });
        //this.close();
    }

    close() {
        if (!this.toggleED.editbox) {
            this.toggleED.editbox = !this.toggleED.editbox;
            this.toggleED.fullbox = !this.toggleED.fullbox;
        }
        this.emitToggleData(this.toggleED);
        this.userDetails.reset()
    }

    alertCall(){
        this.toggleED.formName = this.formName;
        $("#alertPopup").modal("show");
        this.close()
    }

    edit({ value, valid }: { value: OrderRequest, valid: boolean }): void {
        let result = JSON.stringify(value);
        if (!result) {
            return;
        }
        this.appService.update(value, this.editUrl)
            .then(() => {
                this.source.update(this.data, value);
                this.source.refresh();
                this.alertCall()
                return null;
            });
        //this.source.update(this.data, value); no luck here as well
    }
}
