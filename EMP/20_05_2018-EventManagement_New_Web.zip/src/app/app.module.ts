import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { CommonModule } from '@angular/common';

import { AppRoutingModule } from './components/app-root/app-routing.module';
import { LoginRoutingModule } from './components/login/login-routing.module';

import { AppComponent } from './components/app-root/app.component';
import { LoginPageComponent } from './components/login/login-page.component';
import { AuthenticationService } from './components/services/authentication.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';






@NgModule({
  declarations: [
      AppComponent,
      LoginPageComponent
  ],
  imports: [
    BrowserModule,
      AppRoutingModule,
      LoginRoutingModule,
      CommonModule,
      FormsModule,
    HttpModule,
    BrowserAnimationsModule
  ],
  providers: [AuthenticationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
